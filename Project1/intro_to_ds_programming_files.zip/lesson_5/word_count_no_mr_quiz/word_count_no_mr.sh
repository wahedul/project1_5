#! /bin/bash

cat aliceInWonderland.txt | python word_count.py
